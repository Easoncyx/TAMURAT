# Legacy Code

## Question Database

![image-20190327195626892](database_analyse.assets/image-20190327195626892.png)

## Company Database

![image-20190327213312038](database_analyse.assets/image-20190327213312038.png)

## Answer Database

![image-20190327213329188](database_analyse.assets/image-20190327213329188.png)

