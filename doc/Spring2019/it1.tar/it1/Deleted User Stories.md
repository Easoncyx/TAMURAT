## Feature 8 : decisionmaker could register account
- As an decision maker
- So that I could register an account
- I want to use my email, company name(textobx), password and role(decisionmaker) to register
---
## Feature 9 : validator could register account
- As an validator also a user
- So that I could register an account
- I want to use my email, company name(textbox), password and role(validator) to register
---
## Feature 7 : subcontractor could register account
- as a subcontractor
- So that I could register an account
- I want to use my email, company name(textbox), password and role(subcontractor) to register
---
## Feature 6 : More then one validator
- As a validator or decision maker
- I want to see who validates which question
---
## Feature 2 : user creates an account
- As a User
- So that I want to use the function of system
- I want to create an account to be approved by an admin
---
## Feature 13 : Admin or Validator could upload zip file
- As an admin or validator
- So that I could upload zip file to help company without an account
- I want to upload a zip file, which contains csv, pdf and .json(relation between evident and question) file, to the system
---
## Feature 12 : Company could select scenario
- As an company
- So that I could select scenario
- I want to upload evidence related to the scenario
---
## Feature 16: Finish a scenario
- As a decision maker
- So that I could select a company to finish a scenario
- I want to choose a evaluated company from those who select this scenario
---
## Feature 4: admin changes role
- As an administrator
- So that I should manage the priviliage of other accounts
- I want to change the roles of registered users
---