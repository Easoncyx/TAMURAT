# contractor & subcontractor Feature
## Feature 1: company user could upload pdf
- As a company user 
- I want to upload sereral pdf documents as my company evidence
- So that validator can see or download them
---
## Feature 2: Company could be evaluated by answering questions
- As an company user
- So that I could be admitted
- I want to fill the questions(csv file) to get evaluated
---
## Feature 3: contractors invite subcontractors via email
- As a contractor
- So that I need to add subcontractor
- I want to have a seprate page to invite subcontractor via email
---
# Admin Feature
## Feature 4: Admin could approve subcontractor invitation and send log in id & default password through email
- As an admin
- So that I could decide whether subcontractor could register or not
- I want to approve subcontactor invitation and send user id and default pw via email
---
# Decision Maker Feature
## Feature 5: Decision Maker and Admin could set up scenario
- As an Decision Maker or Admin
- So that I could set up scenario
- I want to give each scenario a name and description 
---
## Feature 6: Decision Maker change companies weight at different scenarios
- As a Decision Maker
- So that I could evaluate companies weight depands on scenarios
- I want to give or change companies weight according to different scenarios
---
## Feature 7: Decision Maker could change question weights
- As a Decision Maker
- So that I could evaluate each question
- I want to give or change questions weights
---
# Validator Feature
## Feature 8: Evaluate company
- As a validator
- So that i could evaluate subcontractors and contractor
- I want to give level(drop down), comments(text box), weight of company(text box), weight of question(text box)
---
## Feature 9: More than one validators
- As a decision maker or validator
- So that I could see other validation of questions
- I want to see who validates which question
---

# Function Feature
## Feature 10: users could register account
- As a contractor or decisionmaker or validator
- So that I could register an account
- I want to fill my email, nickname(company name/validator name), password and role and wait for the log in id sent by admin via email.
---
## Feature 11: users could contract admin for support
- As a user
- So that I may meet problems and need help
- I want to have a buttom to contract admin for support 
---
## Feature 12: forget and reset password
- As a user or admin
- So that I may forget or want to change password
- I want to reset password via email

## Feature 13: notice if password incorrect 

- As a user
- So that I want to get notice when password incorrect
- a flash will jump up when password incorrect to note user or admin






